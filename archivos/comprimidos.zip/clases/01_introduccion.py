# Definir que es una clase y poner algun ejemplo ilustrativo que ayude a entender la misma
