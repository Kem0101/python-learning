# ES IMPORTANTE TENER EN CUENTA EL ORDEN DE LA CONDICIONES IF PARA QUE EL PROGRAMA FUNCIONE CORRECTAMENTE

edad = 32

if (edad > 54):
    print("Tiene pase privilegiado")

elif (edad > 20):
    print("Puede pasar en su turno de espera")

else:
    print("No puede pasar")
