"""cadena de operadores"""

EDAD = 60

# if edad >= 15 and edad <= 65:
#     print("Puede entrar a la piscina")

if 15 <= EDAD <= 65:
    print("Puede entrar a la piscina")
