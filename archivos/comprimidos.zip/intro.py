"""Intro to python"""


print("Hola mundo!")
print("Kemuel " * 3)
