try:
    n1 = int(input("Ingrese el primer numero: "))
except:
    print("Ocurrio un error")
