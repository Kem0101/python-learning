# Existen diferentes tipos de errores que podemos tratar según su tipo

try:
    n1 = int(input("Ingrese el primer numero: "))
    pepe
except ValueError as e:
    print("Ingrese un valor que corresponda")
except NameError as e:
    print("Ocurrio un error")
