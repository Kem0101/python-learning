def learning(nombre):  # aqui la funcion recibe parametro que es la variable dentro de la funcion
    print("Hola mundo")
    print(f"Mi nombre es: {nombre}")


# cuando hacemos refencia a la variable fuera de la funcion se llama argumento
learning("Sam Martinez")
