def init(graphql, **_):
    print(f"Soy el paquete uno: {graphql}")