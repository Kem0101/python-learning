# set que significa grupo o conjunto => estos no permiten valores duplicados

primer = {1, 1, 2, 2, 3, 4, 5}
print(primer)

# | union = une los elementos de ambos conjuntos, estos sin duplicidad
# & interseccion = nos devuelve los elementos que se encuentran en ambos sets o conjuntos
# - diferencia = elimina los que se repiten en ambos conjuntos pero se eliminan solo en el conjunto de la izquierda
# ^ diferencia simetrica = elimina los que se repiten en ambos conjuntos

# NOTA: NO PODEMOS ACCEDER A LOS DATOS DE LOS SET PARA EXTRAER UN DATO EN CONCRETO, PERO SI PODEMOS CONSULTAR SI EXISTE UN DATO EN EL SET
