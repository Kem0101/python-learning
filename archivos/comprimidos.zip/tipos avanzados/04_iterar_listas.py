mascotas = ["Purrungo", "Wilo", "Flopi", "Chocolo", "Bartolito"]

for indice, mascota in enumerate(mascotas):
    print(indice, mascota)
