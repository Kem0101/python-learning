numeros = [1, 2, 3,]
letras = ["hola", "mundo"]
palabras = ["Kemuel", "Mi hijo"]
booleans = [True, False]
matriz = [[0, 1], [1, 0]]
ceros = [0] * 10
alfaNumericos = numeros + letras
rango = list(range(1, 11))
chars = list("Hola Mundo")
print(chars)
