mascotas = ["Purrungo", "Wilo", "Flopi", "Chocolo", "Bartolito", "Wilo"]

print(mascotas.count("Wilo"))
if "Purrungo" in mascotas:
    print(mascotas.index("Purrungo"))
