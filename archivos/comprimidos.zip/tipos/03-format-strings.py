nombre = "Sam"
apellido = "Martinez"
nombre_completo = f"{nombre} {apellido}"
# tambien podemos pasarles expresiones a la funcion f o format
nombre_completo = f"{nombre[0]} {2 + 5}"
print(nombre_completo)
