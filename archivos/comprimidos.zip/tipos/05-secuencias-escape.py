# \" \' \\ luego de la barra mostrar el siguiente caracter por pantalla
# \n barra n para dar un salto de linea

curso = "Ultimate \'Python\'"
print(curso)
