# TIPOS
# int()
# str()
# float()
# bool()
# los valores que la funcion de conversion bool devolvera como falsos tambien conocidos como (falsy) en python son => "" string vacios, 0 cero y none
# todos los demas valores que reciba la funcion para convertir tipos bool devolveran true (truthy)

print(bool(""))
print(bool("0"))
print(bool(None))
print(bool(" "))  # esta función considera un espacio en un string como un carácter
print(bool(0))
