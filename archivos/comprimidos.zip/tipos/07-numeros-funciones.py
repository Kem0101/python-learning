import math

# funciones nativas de python para trabajar con numeros
# # funcion para obtener el numero absoluto de un valor


# MODULOS para trabajar con numeros en python
print(math.ceil(1.3))
print(math.floor(1.7))
print(math.pow(10, 3))
print(math.sqrt(9))
print(math.isnan("12"))
