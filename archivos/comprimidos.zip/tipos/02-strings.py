nombre_curso = "Ultime python"
descripcion_curso = """
Ultimate python,
Este curso contempla todos los aspectos que necesitas saber,
para saber para un trabajo como programador
"""

# print(nombre_curso, descripcion_curso)

print(len(nombre_curso))
print(nombre_curso[0])
print(nombre_curso[0:8])
# de esta forma inicia desde el indice 9 hasta la ultima posición
print(nombre_curso[9:])
# de esta forma inicia en el índice cero hasta la posición pasado como segundo parametro
print(nombre_curso[:8])
# inicia desde la posición cero hasta el ultimo indice del string
print(nombre_curso[:])
