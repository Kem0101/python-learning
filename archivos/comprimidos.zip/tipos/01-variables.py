nombre_curso = "python"
alumnos = 5000
puntaje = 9.9
publicado = True
