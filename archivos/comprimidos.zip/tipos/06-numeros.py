numero = 7  # entero
decimal = 1.5  # float
imaginario = 2 + 2j  # en matematica el numero imaginario se representa por i que es igual a la raiz cuadrada de -1 en python se representa con la letra j

# numero = numero + 4
numero += 5  # este operador dice sumale 5 a la variable numero y luego asigna el resultado a la misma, esto lo podemos hacer con cualquier operador matemático
print("numero", numero)

print(1 * 3)
print(1 + 3)
print(1 - 3)
print(1 / 3)
print(1 // 3)  # con las dos barras la división ignora los decimales del resultado
print(8 % 3)  # el modulo nos devuelve el resto (lo que queda luego de dividir)
print(2 ** 3)  # nos permite crear la potencia (el primer numero elevado al segundo)
